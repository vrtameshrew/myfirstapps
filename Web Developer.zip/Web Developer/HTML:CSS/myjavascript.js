window.onload = function() {
    alert("hello!");
}